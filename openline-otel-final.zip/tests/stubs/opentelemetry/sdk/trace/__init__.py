class ReadableSpan:
    pass


class Span:
    pass


class SpanProcessor:
    pass

